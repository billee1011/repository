package com.lingyu.msg.rpc;

public class WriteDataAck {

	private int retCode;

	public int getRetCode() {
		return retCode;
	}

	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

}
