package com.lingyu.common.io;

public class MsgConstant {

	/**场景组*/
	public static final byte GROUP_STAGE = 1;
	/**Bus组*/
	public static final byte GROUP_BUS_CACHE = 2;
	/**public组*/
	public static final byte GROUP_PUBLIC = 3;
	/**个人初始化组*/
	public static final byte GROUP_BUS_INIT = 4;
	/**client*/
	public static final byte GROUP_CLIENT = 5;

}
