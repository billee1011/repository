package com.lingyu.msg.http;

public class KickOffPlayer_S2C_Msg extends HttpMsg{
	private int retCode;

	public int getRetCode() {
		return retCode;
	}

	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

}
