package com.lingyu.msg.http;
public class Query_C2S_Msg
{
	private String sql;
	public String getSql()
	{
		return sql;
	}
	public void setSql(String sql)
	{
		this.sql = sql;
	}
}
