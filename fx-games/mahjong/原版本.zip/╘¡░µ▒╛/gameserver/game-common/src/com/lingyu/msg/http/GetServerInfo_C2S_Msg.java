package com.lingyu.msg.http;

public class GetServerInfo_C2S_Msg extends HttpMsg {

}
