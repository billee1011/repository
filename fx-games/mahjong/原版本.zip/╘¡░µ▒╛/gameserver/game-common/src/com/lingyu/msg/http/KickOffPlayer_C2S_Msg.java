package com.lingyu.msg.http;

public class KickOffPlayer_C2S_Msg {
	private String reason;// 踢玩家下线原因

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
