package com.lingyu.msg.http;

public class VersionNotic_S2C_Msg extends HttpMsg{
}
