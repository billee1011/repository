package com.lingyu.msg.rpc;

public class LoadUserDataReq {
	private long userId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
}