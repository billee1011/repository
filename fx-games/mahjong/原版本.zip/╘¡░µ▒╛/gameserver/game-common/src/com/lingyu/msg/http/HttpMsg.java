package com.lingyu.msg.http;

public abstract class HttpMsg {
	private int worldId;
	private String worldName;

	public int getWorldId() {
		return worldId;
	}

	public void setWorldId(int worldId) {
		this.worldId = worldId;
	}

	public String getWorldName() {
		return worldName;
	}

	public void setWorldName(String worldName) {
		this.worldName = worldName;
	}

}
