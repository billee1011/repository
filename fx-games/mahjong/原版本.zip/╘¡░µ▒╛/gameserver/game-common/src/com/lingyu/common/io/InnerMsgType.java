package com.lingyu.common.io;

/**
 * 内部消息类型申明类.
 * <p>
 * 建议把值改成数字形式,以便顺序命名，例"inner:68000"
 * 
 */
public class InnerMsgType {

}