package com.lingyu.msg.http;

public interface ISerialaIdable {
	public void setSerialId(int serialId);

	public int getSerialId();
}
