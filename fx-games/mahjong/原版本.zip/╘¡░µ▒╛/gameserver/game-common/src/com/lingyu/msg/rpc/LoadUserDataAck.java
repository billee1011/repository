package com.lingyu.msg.rpc;


public class LoadUserDataAck<T> {

	private T result;

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}
}
