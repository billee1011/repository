package com.lingyu.common.constant;

import java.util.Date;

public class TimeConstant {
	/** 2000-01-01 00:00:00 */
	public static final long LONG_AGO = 946656000000l;
	/** 2000-01-01 00:00:00 */
	public static final Date DATE_LONG_AGO = new Date(LONG_AGO);

}
