package com.lingyu.msg.http;

public class AnnounceDelete_C2S_Msg {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
