package com.lingyu.game.service.id;

public class TableNameConstant {
	
	public static final String ROLE = "role";
	public static final String USER = "user";
	public static final String MAHJONG_RESULT_LOG = "mahjong_result_log";
	public static final String ANNOUNCE = "announce";
	public static final String MAIL = "mail";
	public static final String MONEY_FOLW_LOG = "money_flow_log";

}
