package com.lingyu.common.template;

import com.lingyu.common.template.gen.FanTemplateGen;

/***
 * 翻的倍数模板
 * @author wangning
 * @date 2017年1月19日 上午10:56:57
 */
public class FanTemplate extends FanTemplateGen {

	public void deserialize(){
		
	}
}
