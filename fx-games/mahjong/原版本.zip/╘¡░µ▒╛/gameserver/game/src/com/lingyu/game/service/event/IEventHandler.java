package com.lingyu.game.service.event;

public interface IEventHandler {
	String getModule();
}
