package com.lingyu.common.io;

import com.lingyu.game.GameServerContext;
import com.lingyu.game.RouteManager;

public class BroadcastMsg implements IMsg {
	private static RouteManager routeManager = GameServerContext.getBean(RouteManager.class);
	private int command;
	private Object[] result;

	public BroadcastMsg(int command, Object[] result) {
		this.command = command;
		this.result = result;
	}

	@Override
	public void flush() {
		routeManager.broadcast(command, result);
	}

}