package com.lingyu.game.service.id;

public class IdMaxConstant {
	
	/** role表id起始值*/
	public static final long ROLE = 10000l;
	/** user表id起始值*/
	public static final long USER = 1000000l;
	/** 通用表id起始值*/
	public static final long COMMON = 0l;
	
	

}
