/**
 * 
 */
package com.lingyu.game.action.publik;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lingyu.common.constant.ModuleConstant;
import com.lingyu.common.constant.SystemConstant;
import com.lingyu.common.io.MsgType;
import com.lingyu.common.message.GameAction;
import com.lingyu.common.message.GameMapping;
import com.lingyu.common.util.ConvertObjectUtil;
import com.lingyu.game.RouteManager;
import com.lingyu.game.service.mahjong.MahjongManager;

@Controller
@GameAction(module = ModuleConstant.MODULE_PLAY_MAHJONG, group = SystemConstant.GROUP_PUBLIC)
public class PlayMahjongAction {

	@Autowired
	private RouteManager routeManager;
	@Autowired
	private MahjongManager mahjongManager;

	@GameMapping(value = MsgType.CREATE_MAHJONG_ROOM)
	public void createMahjongRoom(long roleId, Object[] msg) {
		int jushu = (int)msg[0];
		int zimohu = (int)msg[1];
		int feng = (int)msg[2];
		int hz = (int)msg[3]; // 红中赖子
		int yu = (int)msg[4];
		int roomId = 0;
		if(msg.length >= 6){
			roomId = (int)msg[5];
		}
		Object result[] = mahjongManager.createRoom(roleId, jushu, zimohu, feng, hz, yu, roomId);
		routeManager.relayMsg(roleId, MsgType.CREATE_MAHJONG_ROOM, result);
	}
	
	@GameMapping(value = MsgType.JOIN_MAHJONG_MSG)
	public void joinMahjongRoom(long roleId, Object[] msg) {
		int roomNum = (int)msg[0];
		Object result[] = mahjongManager.joinRoom(roleId, roomNum);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.JOIN_MAHJONG_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_PLAY_MSG)
	public void play(long roleId, Object[] msg) {
		int paiId = (int)msg[0];
		Object result[] = mahjongManager.play(roleId, paiId);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_PLAY_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.DISSOLVED_ROOM_MSG)
	public void dissolvedRoom(long roleId, Object[] msg) {
		Object result[] = mahjongManager.dissolvedRoom(roleId);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.DISSOLVED_ROOM_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.QUIT_ROOM_MSG)
	public void quitRoom(long roleId, Object[] msg) {
		Object result[] = mahjongManager.quitRoom(roleId);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.QUIT_ROOM_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_CHESS_SIGN_MSG)
	public void sign(long roleId, Object[] msg) {
		int signType = (int)msg[0];
		Object result[] = mahjongManager.sign(roleId, signType);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_CHESS_SIGN_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_START_GAME_MSG)
	public void startGame(long roleId, Object[] msg) {
		Object result[] = mahjongManager.startGame(roleId);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_START_GAME_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_DISMISS_MSG)
	public void disMiss(long roleId, Object[] msg) {
		Object result[] = mahjongManager.disMiss(roleId);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_DISMISS_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_DISMISS_OPERATE_MSG)
	public void disMissOperate(long roleId, Object[] msg) {
		int type = (int)msg[0];
		Object result[] = mahjongManager.disMissOperate(roleId, type);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_DISMISS_OPERATE_MSG, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_ZHANJI_INFO)
	public void getZhanJiInfo(long roleId, Object[] msg) {
		int pageNum = (int)msg[0];
		Object result[] = mahjongManager.getZhanJiInfo(roleId, pageNum);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_ZHANJI_INFO, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_ZHANJI_DETAILS_INFO)
	public void getZhanJiDetailsInfo(long roleId, Object[] msg) {
		long id = ConvertObjectUtil.obj2long(msg[0]);
		Object result[] = mahjongManager.getZhanJiDetailsInfo(roleId, id);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_ZHANJI_DETAILS_INFO, result);
		}
	}
	
	@GameMapping(value = MsgType.MAHJONG_ZHANJI_PLAYBACK)
	public void playBack(long roleId, Object[] msg) {
		long id = ConvertObjectUtil.obj2long(msg[0]);
		int jushu = ConvertObjectUtil.object2int(msg[1]);
		Object result[] = mahjongManager.playBack(roleId, id, jushu);
		if(result != null){
			routeManager.relayMsg(roleId, MsgType.MAHJONG_ZHANJI_PLAYBACK, result);
		}
	}
}