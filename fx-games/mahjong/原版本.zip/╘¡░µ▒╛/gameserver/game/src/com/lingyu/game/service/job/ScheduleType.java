package com.lingyu.game.service.job;

public class ScheduleType {
	// ------------------角色系统-------------------------------
	/** 解散房间多久后默认解散 */
	public final static byte DISMISS_MIN = 1;
}