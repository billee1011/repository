package com.lingyu.common.cache;

/**
 * 缓存系统的常量类.
 * 
 * @author 小流氓<zhoumingkai@lingyuwangluo.com>
 */
public class CacheConstant {

	// -----------------临时缓存Key常量-----------------------------------------------
}