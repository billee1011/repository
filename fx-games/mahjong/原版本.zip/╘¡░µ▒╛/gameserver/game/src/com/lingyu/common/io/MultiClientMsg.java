package com.lingyu.common.io;

import com.lingyu.game.GameServerContext;
import com.lingyu.game.RouteManager;

public class MultiClientMsg implements IMsg {
	private static RouteManager routeManager = GameServerContext.getBean(RouteManager.class);
	private long[] roleIds;
	private int command;
	private Object[] result;

	public MultiClientMsg(long[] roleIds, int command, Object[] result) {
		this.roleIds = roleIds;
		this.command = command;
		this.result = result;
	}

	public void flush() {
		routeManager.broadcast(roleIds, command, result);
	}

}