package com.lingyu.game.service.user;

public class UserConstant {
	// 角色权限
	/** 新手指导员 */
	public final static int TYPE_INSTRUCTOR = 0;
	/** 普通玩家 */
	public final static int TYPE_PLAYER = 1;
	/** GM */
	public final static int TYPE_GM = 2;

}
