package com.lingyu;

public class TestVo {
	private int msgType;
	private Object msg[];
	public int getMsgType() {
		return msgType;
	}
	public void setMsgType(int msgType) {
		this.msgType = msgType;
	}
	public Object[] getMsg() {
		return msg;
	}
	public void setMsg(Object[] msg) {
		this.msg = msg;
	}
}
