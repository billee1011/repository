package com.lingyu.common.io;

public interface IMsg {
	public void flush();
}