package com.lingyu.common.template;

import com.lingyu.common.template.gen.JiFenTemplateGen;

/**
 * 积分匹配表
 * 
 * @author wangning
 * 
 */
public class JiFenTemplate extends JiFenTemplateGen {

	public void deserialize(){
		
	}
}
