package com.lingyu.common.io;

import com.lingyu.game.GameServerContext;
import com.lingyu.game.RouteManager;

public  class BusMsg implements IMsg {
	private static RouteManager routeManager=GameServerContext.getBean(RouteManager.class);
	private long roleId;
	private int command;
	private Object[] result;

	public BusMsg(long roleId, int command, Object[] result) {
		this.roleId = roleId;
		this.command = command;
		this.result = result;
	}

	public void flush() {
		routeManager.relay2BusCache(roleId, command, result);
	}

}