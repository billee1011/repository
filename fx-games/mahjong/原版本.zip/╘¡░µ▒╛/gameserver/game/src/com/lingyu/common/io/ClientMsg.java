package com.lingyu.common.io;

import com.lingyu.game.GameServerContext;
import com.lingyu.game.RouteManager;

public class ClientMsg implements IMsg {
	private static RouteManager routeManager=GameServerContext.getBean(RouteManager.class);
	private long roleId;
	private int command;
	private Object[] result;

	public ClientMsg(long roleId, int command, Object[] result) {
		this.roleId = roleId;
		this.command = command;
		this.result = result;
	}

	public void flush() {
		routeManager.relayMsg(roleId, command, result);
	}

}