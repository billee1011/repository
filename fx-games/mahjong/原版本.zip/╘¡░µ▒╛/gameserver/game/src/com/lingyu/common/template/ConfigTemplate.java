package com.lingyu.common.template;

import com.lingyu.common.template.gen.ConfigTemplateGen;

public class ConfigTemplate extends ConfigTemplateGen {

}
