/**
 * 网络存储策略实现包.
 * <p>
 * 整个系统的亮点在这里，这才是最神奇的想法，才是这个系统的核心功能，我们一起来实现吧~~~
 */
package com.lingyu.noark.data.accessor.network;