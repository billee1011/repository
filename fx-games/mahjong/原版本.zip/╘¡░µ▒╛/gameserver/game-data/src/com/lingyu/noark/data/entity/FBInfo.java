package com.lingyu.noark.data.entity;

public class FBInfo {
	private String id;

	public FBInfo() {

	}

	public FBInfo(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
