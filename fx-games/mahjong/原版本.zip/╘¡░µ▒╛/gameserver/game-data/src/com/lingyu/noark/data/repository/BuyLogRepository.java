package com.lingyu.noark.data.repository;

import com.lingyu.noark.data.entity.BuyLog;

//@Repository
public class BuyLogRepository extends LogRepository<BuyLog> {
}
