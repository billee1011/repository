package com.lingyu.noark.data.exception;

public class NoDataAccessorException extends RuntimeException {
	private static final long serialVersionUID = 1943687253399065724L;

	public NoDataAccessorException(String message) {
		super(message);
	}
}
