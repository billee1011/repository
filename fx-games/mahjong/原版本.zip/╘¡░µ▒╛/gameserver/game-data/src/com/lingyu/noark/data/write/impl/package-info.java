/**
 * 异步回写策略具体实现包.
 */
package com.lingyu.noark.data.write.impl;