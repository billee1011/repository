/**
 * 系统工具包.
 */
package com.lingyu.noark.data.kit;