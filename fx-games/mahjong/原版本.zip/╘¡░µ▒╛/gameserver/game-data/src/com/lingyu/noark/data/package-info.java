/**
 * 数据存储层.
 */
package com.lingyu.noark.data;