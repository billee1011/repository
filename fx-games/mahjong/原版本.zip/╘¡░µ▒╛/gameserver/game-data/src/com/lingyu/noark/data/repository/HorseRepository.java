package com.lingyu.noark.data.repository;

import com.lingyu.noark.data.entity.Horse;

//@Repository
public class HorseRepository extends UniqueCacheRepository<Horse, Long> {

}
