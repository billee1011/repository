package com.lingyu.noark.data.accessor.redis;

import java.io.Serializable;

interface IRoleData {
	public Serializable getRoleId();
}
