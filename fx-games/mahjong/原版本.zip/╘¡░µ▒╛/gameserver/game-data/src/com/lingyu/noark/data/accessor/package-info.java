/**
 * 数据存储策略包.
 * <p>
 * Sql、Nosql 和 Network 三大类实现.
 */
package com.lingyu.noark.data.accessor;