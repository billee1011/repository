package com.lingyu.noark.data.repository;

import com.lingyu.noark.data.entity.Member;

//@Repository
public class MemberRepository extends MultiCacheRepository<Member, Long> {

}
