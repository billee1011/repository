/**
 * ORM注解包.
 */
package com.lingyu.noark.data.annotation;