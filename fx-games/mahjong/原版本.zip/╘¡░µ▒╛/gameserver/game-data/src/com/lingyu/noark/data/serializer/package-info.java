/**
 * 这个包主要处理序列化的工作.
 * <p>
 * 数据的深拷贝先放一放，反射动态生成新对象并复制属性 未实现Cloneable的自行复制
 */
package com.lingyu.noark.data.serializer;