package com.lingyu.noark.data.annotation;

public @interface Version {

}
