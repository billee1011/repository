package com.lingyu.noark.data.repository;

import com.lingyu.noark.data.entity.Role;

//@Repository
public class RoleRepository extends OrmRepository<Role, Long> {

}
