package com.lingyu.noark.data.repository;

import com.lingyu.noark.data.entity.ServerInfo;

//@Repository
public class ServerInfoRepository extends UniqueCacheRepository<ServerInfo, Integer> {

}
