/**
 * 
 */
package com.lingyu.noark.data.cache.impl;